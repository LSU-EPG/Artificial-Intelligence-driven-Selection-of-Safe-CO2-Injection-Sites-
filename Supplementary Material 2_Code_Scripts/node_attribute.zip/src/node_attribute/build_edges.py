from __future__ import annotations

import pandas as pd
import geopandas as gpd
from itertools import product

from .config import (
    EJS_SHEET,
    OUT_SINK_CANDIDATE,
    OUT_POP_EDGES,
    OUT_SINK_SOURCE,
    OUT_SINK_PIPELINE,
    EJS_EXCEL,
    CANDIDATE_RANDOM_SHP,
    CANDIDATE_CLASSII_SHP,
    SOURCE_SHP,
    PIPELINE_SHP,
)
from .geo import geodesic_km, within_miles
from .io import load_ejs, load_shapefile, save_csv

# -----------------------
# Column assumptions
# -----------------------
# Excel must contain: ID, Latitude, Longitude
SINK_ID_COL = "ID"
LAT_COL = "Latitude"
LON_COL = "Longitude"

# Population / tract fields (as used in your notebook)
TRACT_ID_COL = "TractID"
TRACT_LAND_COL = "TractLandm"
TOTPOP_COL = "TotPop"

def _coerce_latlon(df: pd.DataFrame, lat_col: str = LAT_COL, lon_col: str = LON_COL) -> pd.DataFrame:
    df = df.copy()
    df[lat_col] = pd.to_numeric(df[lat_col], errors="coerce")
    df[lon_col] = pd.to_numeric(df[lon_col], errors="coerce")
    df = df.dropna(subset=[lat_col, lon_col])
    # sanity bounds
    df = df[(df[lat_col].between(-90, 90)) & (df[lon_col].between(-180, 180))]
    return df

def build_sink_candidate_edges() -> pd.DataFrame:
    """Build sink -> candidate edge list with distances (km).

    Sinks come from the Excel file (ID/Latitude/Longitude).
    Candidates come from two shapefiles; their 'ID' field is expected.
    Output: outputs/sink_candidate_edgelist.csv
    """
    df_sinks = load_ejs(EJS_SHEET)
    if not {SINK_ID_COL, LAT_COL, LON_COL}.issubset(df_sinks.columns):
        raise ValueError(f"Excel missing required columns: {{'{SINK_ID_COL}','{LAT_COL}','{LON_COL}'}}")

    df_sinks = _coerce_latlon(df_sinks[[SINK_ID_COL, LAT_COL, LON_COL]])

    gdf_rand = load_shapefile(CANDIDATE_RANDOM_SHP)
    gdf_class2 = load_shapefile(CANDIDATE_CLASSII_SHP)

    for gdf, name in [(gdf_rand, "random"), (gdf_class2, "classII")]:
        if "geometry" not in gdf.columns:
            raise ValueError(f"Candidate shapefile '{name}' has no geometry column")
        if "ID" not in gdf.columns:
            raise ValueError(f"Candidate shapefile '{name}' missing 'ID' column")

    # Extract coordinates from geometry (convert to EPSG:4326 already attempted in loader)
    gdf_rand = gdf_rand.copy()
    gdf_class2 = gdf_class2.copy()
    gdf_rand[LAT_COL] = gdf_rand.geometry.y
    gdf_rand[LON_COL] = gdf_rand.geometry.x
    gdf_class2[LAT_COL] = gdf_class2.geometry.y
    gdf_class2[LON_COL] = gdf_class2.geometry.x

    df_candidates = pd.concat(
        [
            gdf_rand[["ID", LAT_COL, LON_COL]],
            gdf_class2[["ID", LAT_COL, LON_COL]],
        ],
        ignore_index=True,
    )
    df_candidates = _coerce_latlon(df_candidates)

    edge_rows = []
    for (sink_id, sink_lat, sink_lon), (cand_id, cand_lat, cand_lon) in product(
        df_sinks[[SINK_ID_COL, LAT_COL, LON_COL]].values,
        df_candidates[["ID", LAT_COL, LON_COL]].values,
    ):
        dist_km = geodesic_km(sink_lat, sink_lon, cand_lat, cand_lon)
        edge_rows.append([sink_id, cand_id, dist_km, "Candidate"])

    edge_df = pd.DataFrame(edge_rows, columns=["From", "To", "Dist_Km", "Type"])
    save_csv(edge_df, OUT_SINK_CANDIDATE)
    return edge_df

def add_population_to_edges(max_miles: float = 30.0) -> pd.DataFrame:
    """Create edges from nodes in sink-candidate list to nearby population (tract) nodes within `max_miles`.

    Reads: outputs/sink_candidate_edgelist.csv
    Writes: outputs/sink_candidate_population_edgelist.csv
    """
    sink_cand = pd.read_csv(OUT_SINK_CANDIDATE)
    ejs = load_ejs(EJS_SHEET)

    # Some datasets use EJS_* prefixed fields; map them if present
    ejs = ejs.rename(columns={
        "EJS_TractID": TRACT_ID_COL,
        "EJS_TractLandm": TRACT_LAND_COL,
        "EJS_TotPop": TOTPOP_COL,
    })

    required_ejs = {TRACT_ID_COL, LAT_COL, LON_COL, TRACT_LAND_COL, TOTPOP_COL}
    if not required_ejs.issubset(ejs.columns):
        raise ValueError(f"Excel missing required tract columns: {required_ejs - set(ejs.columns)}")

    # attach sink coordinates to each From node
    # In your notebook you merged From with sink coordinates (from Excel ID).
    # We'll do the same, but guard if already present.
    if LAT_COL not in sink_cand.columns or LON_COL not in sink_cand.columns:
        sinks = _coerce_latlon(load_ejs(EJS_SHEET)[[SINK_ID_COL, LAT_COL, LON_COL]])
        sink_cand = sink_cand.merge(
            sinks,
            left_on="From",
            right_on=SINK_ID_COL,
            how="left",
        )

    sink_cand = _coerce_latlon(sink_cand, LAT_COL, LON_COL)
    ejs = _coerce_latlon(ejs, LAT_COL, LON_COL)

    edge_rows = []
    for (node_id, node_lat, node_lon), (tract_id, pop_lat, pop_lon, tract_land, tot_pop) in product(
        sink_cand[["From", LAT_COL, LON_COL]].values,
        ejs[[TRACT_ID_COL, LAT_COL, LON_COL, TRACT_LAND_COL, TOTPOP_COL]].values,
    ):
        if within_miles(node_lat, node_lon, pop_lat, pop_lon, max_miles):
            dist_km = geodesic_km(node_lat, node_lon, pop_lat, pop_lon)
            edge_rows.append([node_id, tract_id, dist_km, tract_land, tot_pop])

    edge_df = pd.DataFrame(edge_rows, columns=["From", "To", "Dist_Km", TRACT_LAND_COL, TOTPOP_COL])
    edge_df["Type"] = "PopulationCluster"
    save_csv(edge_df, OUT_POP_EDGES)
    return edge_df

def build_sink_source_edges() -> pd.DataFrame:
    """Build edges from Excel nodes (From) to CO2 source nodes (To).

    Output includes optional TonsCO2e if found.
    """
    df = load_ejs(EJS_SHEET)
    df = df.rename(columns={SINK_ID_COL: "From"})
    if not {"From", LAT_COL, LON_COL}.issubset(df.columns):
        raise ValueError("Excel must contain ID/Latitude/Longitude")
    df = _coerce_latlon(df[["From", LAT_COL, LON_COL]])

    gdf = load_shapefile(SOURCE_SHP)

    # robust column detection (as in your notebook)
    source_id_col = next((c for c in ["GHGRP_ID", "To", "ID", "FID"] if c in gdf.columns), None)
    co2_col = next((c for c in ["GHG_QUANTI", "TonsCO2e", "CO2", "Emissions"] if c in gdf.columns), None)

    if source_id_col is None:
        raise ValueError("Source shapefile is missing an ID column (expected one of GHGRP_ID/To/ID/FID)")
    gdf = gdf.rename(columns={source_id_col: "To"})
    if co2_col is not None:
        gdf = gdf.rename(columns={co2_col: "TonsCO2e"})

    # centroid coordinates
    gdf = gdf.copy()
    gdf["centroid_lat"] = gdf.geometry.centroid.y
    gdf["centroid_lon"] = gdf.geometry.centroid.x

    edge_rows = []
    for (from_id, lat1, lon1), (to_id, lat2, lon2) in product(
        df[["From", LAT_COL, LON_COL]].values,
        gdf[["To", "centroid_lat", "centroid_lon"]].values,
    ):
        dist_km = geodesic_km(lat1, lon1, lat2, lon2)
        if "TonsCO2e" in gdf.columns:
            # We'll attach later by merge to avoid repeated lookup
            edge_rows.append([from_id, to_id, dist_km, "Source"])
        else:
            edge_rows.append([from_id, to_id, dist_km, "Source"])

    edge_df = pd.DataFrame(edge_rows, columns=["From", "To", "Dist_Km", "Type"])

    if "TonsCO2e" in gdf.columns:
        # Attach emission to To
        edge_df = edge_df.merge(gdf[["To", "TonsCO2e"]], on="To", how="left")

    save_csv(edge_df, OUT_SINK_SOURCE)
    return edge_df

def build_sink_pipeline_edges() -> pd.DataFrame:
    """Build edges from Excel nodes (From) to pipeline features (To)."""
    df = load_ejs(EJS_SHEET).rename(columns={SINK_ID_COL: "From"})
    df = _coerce_latlon(df[["From", LAT_COL, LON_COL]])

    gdf = load_shapefile(PIPELINE_SHP)

    if "PLINE_ID" in gdf.columns:
        gdf = gdf.rename(columns={"PLINE_ID": "To"})
    elif "To" not in gdf.columns:
        raise ValueError("Pipeline shapefile is missing PLINE_ID (or To) column")

    gdf = gdf.copy()
    gdf["To"] = gdf["To"].astype(str)

    gdf[LAT_COL] = gdf.geometry.centroid.y
    gdf[LON_COL] = gdf.geometry.centroid.x
    gdf = gdf.dropna(subset=[LAT_COL, LON_COL])

    edge_rows = []
    for (from_id, lat1, lon1), (to_id, lat2, lon2) in product(
        df[["From", LAT_COL, LON_COL]].values,
        gdf[["To", LAT_COL, LON_COL]].values,
    ):
        if -90 <= lat1 <= 90 and -90 <= lat2 <= 90:
            dist_km = geodesic_km(lat1, lon1, lat2, lon2)
            edge_rows.append([from_id, to_id, dist_km, "Pipeline"])

    edge_df = pd.DataFrame(edge_rows, columns=["From", "To", "Dist_Km", "Type"])
    save_csv(edge_df, OUT_SINK_PIPELINE)
    return edge_df
