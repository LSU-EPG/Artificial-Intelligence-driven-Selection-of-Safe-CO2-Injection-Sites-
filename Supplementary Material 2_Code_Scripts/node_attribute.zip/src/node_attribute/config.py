from pathlib import Path

# Project root = two levels above this file:  <root>/src/node_attribute/config.py
PROJECT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_DIR / "data" / "raw"
OUTPUT_DIR = PROJECT_DIR / "outputs"

# -----------------------
# Inputs (edit as needed)
# -----------------------
EJS_EXCEL = DATA_DIR / "Database_with_Spatial_Analysis_final.xlsx"
EJS_SHEET = "Sheet1"

CANDIDATE_RANDOM_SHP = DATA_DIR / "random_points1000.shp"
CANDIDATE_CLASSII_SHP = DATA_DIR / "LA_NETL_SONRIS_VI_Dry.shp"

SOURCE_SHP = DATA_DIR / "LA_CO2_Source.shp"
PIPELINE_SHP = DATA_DIR / "LA_CO2Pipe.shp"

# -----------------------
# Outputs
# -----------------------
OUT_SINK_CANDIDATE = OUTPUT_DIR / "sink_candidate_edgelist.csv"
OUT_POP_EDGES = OUTPUT_DIR / "sink_candidate_population_edgelist.csv"
OUT_POP_EDGES_UPDATED = OUTPUT_DIR / "sink_candidate_population_edgelist_updated.csv"
OUT_SINK_SOURCE = OUTPUT_DIR / "sink_candidate_source_edgelist.csv"
OUT_SINK_PIPELINE = OUTPUT_DIR / "sink_candidate_pipeline_edgelist.csv"
OUT_MERGED = OUTPUT_DIR / "merged_edge_list.csv"
