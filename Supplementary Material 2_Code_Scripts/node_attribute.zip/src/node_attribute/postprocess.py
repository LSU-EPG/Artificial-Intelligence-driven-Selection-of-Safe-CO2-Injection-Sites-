from __future__ import annotations

import pandas as pd

from .config import (
    OUT_SINK_CANDIDATE,
    OUT_POP_EDGES,
    OUT_SINK_SOURCE,
    OUT_SINK_PIPELINE,
    OUT_MERGED,
)
from .io import save_csv

def merge_edge_lists() -> pd.DataFrame:
    """Merge all produced edge lists into a single CSV with a union of columns."""
    files = [
        OUT_SINK_CANDIDATE,
        OUT_POP_EDGES,
        OUT_SINK_SOURCE,
        OUT_SINK_PIPELINE,
    ]

    merged: pd.DataFrame | None = None

    for path in files:
        if not path.exists():
            continue
        cur = pd.read_csv(path)

        if merged is None:
            merged = cur.copy()
        else:
            # union columns
            all_cols = set(merged.columns) | set(cur.columns)
            for col in all_cols:
                if col not in merged.columns:
                    merged[col] = pd.NA
                if col not in cur.columns:
                    cur[col] = pd.NA
            merged = pd.concat([merged, cur], ignore_index=True)

    if merged is None:
        merged = pd.DataFrame(columns=["From", "To", "Dist_Km", "Type"])

    save_csv(merged, OUT_MERGED)
    return merged
