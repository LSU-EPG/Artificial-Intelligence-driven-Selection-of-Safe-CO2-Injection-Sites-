from __future__ import annotations

from pathlib import Path
import pandas as pd
import geopandas as gpd

from .config import EJS_EXCEL, EJS_SHEET

def ensure_output_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

def load_ejs(sheet: str | None = None) -> pd.DataFrame:
    """Load the main Excel dataset (EJS + sink nodes)."""
    return pd.read_excel(EJS_EXCEL, sheet_name=(sheet or EJS_SHEET), engine="openpyxl")

def load_shapefile(path: Path) -> gpd.GeoDataFrame:
    """Load a shapefile into EPSG:4326."""
    gdf = gpd.read_file(path)
    # If shapefile has no CRS but has lon/lat columns, you may need to set it manually.
    if gdf.crs is None:
        # Leave as-is; caller can handle. Most inputs will have CRS.
        pass
    try:
        gdf = gdf.to_crs(epsg=4326)
    except Exception:
        # If CRS unknown, keep original; downstream centroid extraction still works but lat/lon may be wrong.
        pass
    return gdf

def save_csv(df: pd.DataFrame, path: Path, *, index: bool = False) -> None:
    ensure_output_dir(path)
    df.to_csv(path, index=index)
