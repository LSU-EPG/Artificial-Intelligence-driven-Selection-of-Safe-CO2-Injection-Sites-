from __future__ import annotations

from geopy.distance import geodesic

MILES_TO_KM = 1.609344

def geodesic_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in kilometers using geopy."""
    return float(geodesic((lat1, lon1), (lat2, lon2)).kilometers)

def within_miles(lat1: float, lon1: float, lat2: float, lon2: float, miles: float) -> bool:
    """Return True if two coordinates are within `miles` miles."""
    return float(geodesic((lat1, lon1), (lat2, lon2)).miles) <= float(miles)
