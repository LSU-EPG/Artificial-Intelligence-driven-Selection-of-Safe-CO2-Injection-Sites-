Place your input datasets in `data/raw/` with the following filenames (edit `src/node_attribute/config.py` if yours differ):

- Database_with_Spatial_Analysis_final.xlsx
- random_points1000.shp (+ all sidecar files: .dbf, .shx, .prj, etc.)
- LA_NETL_SONRIS_VI_Dry.shp (+ sidecar files)
- LA_CO2_Source.shp (+ sidecar files)
- LA_CO2Pipe.shp (+ sidecar files)

Large raw datasets are usually not committed to Git. Keep them locally.
