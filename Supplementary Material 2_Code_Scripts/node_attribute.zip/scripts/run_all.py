from node_attribute.build_edges import (
    build_sink_candidate_edges,
    add_population_to_edges,
    build_sink_source_edges,
    build_sink_pipeline_edges,
)
from node_attribute.postprocess import merge_edge_lists

def main():
    build_sink_candidate_edges()
    add_population_to_edges(max_miles=30.0)
    build_sink_source_edges()
    build_sink_pipeline_edges()
    merge_edge_lists()

if __name__ == "__main__":
    main()
