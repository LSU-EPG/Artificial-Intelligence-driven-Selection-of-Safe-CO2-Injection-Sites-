from edge_list.builders import (
    build_sink_sink_edges,
    build_sink_candidate_edges,
    build_sink_population_edges,
    build_sink_source_edges,
    build_sink_pipeline_edges,
)
from edge_list.merge import merge_all

def main():
    build_sink_sink_edges(class_value="VI")
    build_sink_candidate_edges()
    build_sink_population_edges(max_miles=30.0)
    build_sink_source_edges()
    build_sink_pipeline_edges()
    merge_all()

if __name__ == "__main__":
    main()
