# edge_list

Build multiple edge lists used in the CO2 site selection workflow and merge them into a single CSV.

This codebase is a **source-code refactor** of a Jupyter workflow (not committed).

## What it generates (in `outputs/`)
- `sink_node_edgelist_filtered.csv` (all-to-all sink distances for Class == "VI")
- `sink_candidate_edgelist.csv`
- `sink_population_edgelist.csv`
- `sink_source_edgelist.csv`
- `sink_pipeline_edgelist.csv`
- `merged_edge_list.csv` (all of the above concatenated with unioned columns)

## Inputs (place in `data/raw/`)
Filenames are configured in `src/edge_list/config.py`. By default it expects:
- `Database_with_Spatial_Analysis_final.xlsx`
- `Output_Geospatial_Analysis_Final_filled.xlsx`
- `random_points1000.shp` (+ sidecars)
- `LA_NETL_SONRIS_VI_Class_II_Shut_In.shp` (+ sidecars)  *(edit name if yours differs)*
- `LA_Pop_Cluster.shp` (+ sidecars)
- `LA_CO2_Source.shp` (+ sidecars)
- `LA_CO2Pipe.shp` (+ sidecars)

## Quickstart
```bash
python -m venv .venv
# activate venv
pip install -r requirements.txt
pip install -e .

python scripts/run_all.py
```

## Notes
- No absolute paths are used anywhere; everything is relative via `config.py`.
- Raw data (`data/raw/`) and outputs (`outputs/`) are gitignored by default.
