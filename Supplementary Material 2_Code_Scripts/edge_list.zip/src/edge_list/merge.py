from __future__ import annotations

import pandas as pd
from .config import (
    OUT_SINK_SINK, OUT_SINK_CANDIDATE, OUT_SINK_POP, OUT_SINK_SOURCE, OUT_SINK_PIPELINE, OUT_MERGED
)
from .io import write_csv

def merge_all() -> pd.DataFrame:
    files = [OUT_SINK_SINK, OUT_SINK_CANDIDATE, OUT_SINK_POP, OUT_SINK_SOURCE, OUT_SINK_PIPELINE]
    merged: pd.DataFrame | None = None

    for f in files:
        if not f.exists():
            continue
        cur = pd.read_csv(f)
        if merged is None:
            merged = cur.copy()
        else:
            all_cols = set(merged.columns) | set(cur.columns)
            for col in all_cols:
                if col not in merged.columns:
                    merged[col] = pd.NA
                if col not in cur.columns:
                    cur[col] = pd.NA
            merged = pd.concat([merged, cur], ignore_index=True)

    if merged is None:
        merged = pd.DataFrame(columns=["From", "To", "Dist_Km", "Type"])

    write_csv(merged, OUT_MERGED)
    return merged
