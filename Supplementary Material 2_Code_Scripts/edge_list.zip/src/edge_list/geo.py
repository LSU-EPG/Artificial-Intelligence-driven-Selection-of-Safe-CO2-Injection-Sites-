from __future__ import annotations

from geopy.distance import geodesic

def geodesic_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    """Great-circle distance in km."""
    return float(geodesic((lat1, lon1), (lat2, lon2)).kilometers)

def within_miles(lat1: float, lon1: float, lat2: float, lon2: float, miles: float) -> bool:
    """True if distance <= miles."""
    return float(geodesic((lat1, lon1), (lat2, lon2)).miles) <= float(miles)
