from __future__ import annotations

from pathlib import Path
import pandas as pd
import geopandas as gpd

def ensure_dir(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)

def read_excel(path: Path, sheet_name: str) -> pd.DataFrame:
    return pd.read_excel(path, sheet_name=sheet_name, engine="openpyxl")

def read_shp(path: Path) -> gpd.GeoDataFrame:
    gdf = gpd.read_file(path)
    if gdf.crs is not None:
        try:
            gdf = gdf.to_crs(epsg=4326)
        except Exception:
            pass
    return gdf

def write_csv(df: pd.DataFrame, path: Path) -> None:
    ensure_dir(path)
    df.to_csv(path, index=False)
