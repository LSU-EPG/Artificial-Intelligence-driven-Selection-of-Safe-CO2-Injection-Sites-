from __future__ import annotations

import pandas as pd
import numpy as np
from itertools import combinations, product

from .config import (
    MAIN_EXCEL, MAIN_SHEET,
    SINK_EXCEL, SINK_SHEET,
    CANDIDATE_RANDOM_SHP, CLASS_II_SHUTIN_SHP,
    POP_CLUSTER_SHP, SOURCE_SHP, PIPELINE_SHP,
    OUT_SINK_SINK, OUT_SINK_CANDIDATE, OUT_SINK_POP,
    OUT_SINK_SOURCE, OUT_SINK_PIPELINE,
)
from .io import read_excel, read_shp, write_csv
from .geo import geodesic_km, within_miles

# Common column names used in your notebook
ID_COL = "ID"
LAT_COL = "Latitude"
LON_COL = "Longitude"

def _coerce_latlon(df: pd.DataFrame, lat_col: str = LAT_COL, lon_col: str = LON_COL) -> pd.DataFrame:
    df = df.copy()
    df[lat_col] = pd.to_numeric(df[lat_col], errors="coerce")
    df[lon_col] = pd.to_numeric(df[lon_col], errors="coerce")
    df = df.dropna(subset=[lat_col, lon_col])
    df = df[df[lat_col].between(-90, 90) & df[lon_col].between(-180, 180)]
    return df

def build_sink_sink_edges(class_value: str = "VI") -> pd.DataFrame:
    """All-to-all sink distances for rows where Class == `class_value`."""
    df = read_excel(MAIN_EXCEL, MAIN_SHEET)
    required = {ID_COL, LAT_COL, LON_COL, "Class"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"MAIN_EXCEL missing columns: {missing}")

    df = df[df["Class"] == class_value][[ID_COL, LAT_COL, LON_COL]]
    df = _coerce_latlon(df)

    rows = []
    for (id1, lat1, lon1), (id2, lat2, lon2) in combinations(df.values, 2):
        d = geodesic_km(lat1, lon1, lat2, lon2)
        rows.append([id1, id2, d, "Sink"])
        rows.append([id2, id1, d, "Sink"])

    out = pd.DataFrame(rows, columns=["From", "To", "Dist_Km", "Type"])
    write_csv(out, OUT_SINK_SINK)
    return out

def build_sink_candidate_edges() -> pd.DataFrame:
    """Edges from sink nodes (Excel) to candidate nodes (two shapefiles)."""
    sinks = read_excel(SINK_EXCEL, SINK_SHEET)
    required = {ID_COL, LAT_COL, LON_COL}
    missing = required - set(sinks.columns)
    if missing:
        raise ValueError(f"SINK_EXCEL missing columns: {missing}")
    sinks = _coerce_latlon(sinks[[ID_COL, LAT_COL, LON_COL]]).rename(columns={ID_COL: "From"})

    cand1 = read_shp(CANDIDATE_RANDOM_SHP)
    cand2 = read_shp(CLASS_II_SHUTIN_SHP)
    for gdf, name in [(cand1, "random_points"), (cand2, "classII_shutin")]:
        if "ID" not in gdf.columns:
            raise ValueError(f"{name} shapefile missing 'ID' column")

    def _cand_df(gdf: pd.DataFrame) -> pd.DataFrame:
        gdf = gdf.copy()
        gdf[LAT_COL] = gdf.geometry.y
        gdf[LON_COL] = gdf.geometry.x
        return gdf[["ID", LAT_COL, LON_COL]]

    candidates = pd.concat([_cand_df(cand1), _cand_df(cand2)], ignore_index=True)
    candidates = _coerce_latlon(candidates).rename(columns={"ID": "To"})

    rows = []
    for (fid, flat, flon), (tid, tlat, tlon) in product(
        sinks[["From", LAT_COL, LON_COL]].values,
        candidates[["To", LAT_COL, LON_COL]].values,
    ):
        d = geodesic_km(flat, flon, tlat, tlon)
        rows.append([fid, tid, d, "Candidate"])

    out = pd.DataFrame(rows, columns=["From", "To", "Dist_Km", "Type"])
    write_csv(out, OUT_SINK_CANDIDATE)
    return out

def build_sink_population_edges(max_miles: float = 30.0) -> pd.DataFrame:
    """Edges from sinks (Excel) to population clusters (shapefile) within `max_miles`."""
    sinks = read_excel(SINK_EXCEL, SINK_SHEET)
    required = {ID_COL, LAT_COL, LON_COL}
    missing = required - set(sinks.columns)
    if missing:
        raise ValueError(f"SINK_EXCEL missing columns: {missing}")
    sinks = _coerce_latlon(sinks[[ID_COL, LAT_COL, LON_COL]]).rename(columns={ID_COL: "From"})

    pop = read_shp(POP_CLUSTER_SHP).copy()
    pop_id_col = next((c for c in ["TractID", "ID", "To", "FID"] if c in pop.columns), None)
    if pop_id_col is None:
        raise ValueError("POP_CLUSTER_SHP missing an ID-like column (TractID/ID/To/FID)")
    pop = pop.rename(columns={pop_id_col: "To"})
    pop[LAT_COL] = pop.geometry.centroid.y
    pop[LON_COL] = pop.geometry.centroid.x
    pop = pop.dropna(subset=[LAT_COL, LON_COL])

    rows = []
    for (fid, flat, flon), (tid, tlat, tlon) in product(
        sinks[["From", LAT_COL, LON_COL]].values,
        pop[["To", LAT_COL, LON_COL]].values,
    ):
        if within_miles(flat, flon, tlat, tlon, max_miles):
            d = geodesic_km(flat, flon, tlat, tlon)
            rows.append([fid, tid, d, "PopulationCluster"])

    out = pd.DataFrame(rows, columns=["From", "To", "Dist_Km", "Type"])
    write_csv(out, OUT_SINK_POP)
    return out

def build_sink_source_edges() -> pd.DataFrame:
    """Edges from sinks (Excel) to CO2 sources (shapefile)."""
    sinks = read_excel(SINK_EXCEL, SINK_SHEET)
    required = {ID_COL, LAT_COL, LON_COL}
    missing = required - set(sinks.columns)
    if missing:
        raise ValueError(f"SINK_EXCEL missing columns: {missing}")
    sinks = _coerce_latlon(sinks[[ID_COL, LAT_COL, LON_COL]]).rename(columns={ID_COL: "From"})

    src = read_shp(SOURCE_SHP).copy()
    src_id_col = next((c for c in ["GHGRP_ID", "ID", "To", "FID"] if c in src.columns), None)
    if src_id_col is None:
        raise ValueError("SOURCE_SHP missing ID column (GHGRP_ID/ID/To/FID)")
    src = src.rename(columns={src_id_col: "To"})

    co2_col = next((c for c in ["GHG_QUANTI", "TonsCO2e", "CO2", "Emissions"] if c in src.columns), None)
    if co2_col is not None and co2_col != "TonsCO2e":
        src = src.rename(columns={co2_col: "TonsCO2e"})

    src[LAT_COL] = src.geometry.centroid.y
    src[LON_COL] = src.geometry.centroid.x
    src = src.dropna(subset=[LAT_COL, LON_COL])

    rows = []
    for (fid, flat, flon), (tid, tlat, tlon) in product(
        sinks[["From", LAT_COL, LON_COL]].values,
        src[["To", LAT_COL, LON_COL]].values,
    ):
        d = geodesic_km(flat, flon, tlat, tlon)
        rows.append([fid, tid, d, "Source"])

    out = pd.DataFrame(rows, columns=["From", "To", "Dist_Km", "Type"])
    if "TonsCO2e" in src.columns:
        out = out.merge(src[["To", "TonsCO2e"]], on="To", how="left")
    write_csv(out, OUT_SINK_SOURCE)
    return out

def build_sink_pipeline_edges() -> pd.DataFrame:
    """Edges from sinks (Excel) to pipelines (shapefile)."""
    sinks = read_excel(SINK_EXCEL, SINK_SHEET)
    required = {ID_COL, LAT_COL, LON_COL}
    missing = required - set(sinks.columns)
    if missing:
        raise ValueError(f"SINK_EXCEL missing columns: {missing}")
    sinks = _coerce_latlon(sinks[[ID_COL, LAT_COL, LON_COL]]).rename(columns={ID_COL: "From"})

    pl = read_shp(PIPELINE_SHP).copy()
    pl_id_col = next((c for c in ["PLINE_ID", "ID", "To", "FID"] if c in pl.columns), None)
    if pl_id_col is None:
        raise ValueError("PIPELINE_SHP missing ID column (PLINE_ID/ID/To/FID)")
    pl = pl.rename(columns={pl_id_col: "To"})

    pl[LAT_COL] = pl.geometry.centroid.y
    pl[LON_COL] = pl.geometry.centroid.x
    pl = pl.dropna(subset=[LAT_COL, LON_COL])

    rows = []
    for (fid, flat, flon), (tid, tlat, tlon) in product(
        sinks[["From", LAT_COL, LON_COL]].values,
        pl[["To", LAT_COL, LON_COL]].values,
    ):
        d = geodesic_km(flat, flon, tlat, tlon)
        rows.append([fid, tid, d, "Pipeline"])

    out = pd.DataFrame(rows, columns=["From", "To", "Dist_Km", "Type"])
    write_csv(out, OUT_SINK_PIPELINE)
    return out
