from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[2]
DATA_DIR = PROJECT_DIR / "data" / "raw"
OUTPUT_DIR = PROJECT_DIR / "outputs"

# Excel inputs
MAIN_EXCEL = DATA_DIR / "Database_with_Spatial_Analysis_final.xlsx"
MAIN_SHEET = "Sheet1"

SINK_EXCEL = DATA_DIR / "Output_Geospatial_Analysis_Final_filled.xlsx"
SINK_SHEET = "Sheet1"

# Shapefile inputs (edit filenames here if yours differ)
CANDIDATE_RANDOM_SHP = DATA_DIR / "random_points1000.shp"
CLASS_II_SHUTIN_SHP = DATA_DIR / "LA_NETL_SONRIS_VI_Class_II_Shut_In.shp"
POP_CLUSTER_SHP = DATA_DIR / "LA_Pop_Cluster.shp"
SOURCE_SHP = DATA_DIR / "LA_CO2_Source.shp"
PIPELINE_SHP = DATA_DIR / "LA_CO2Pipe.shp"

# Outputs
OUT_SINK_SINK = OUTPUT_DIR / "sink_node_edgelist_filtered.csv"
OUT_SINK_CANDIDATE = OUTPUT_DIR / "sink_candidate_edgelist.csv"
OUT_SINK_POP = OUTPUT_DIR / "sink_population_edgelist.csv"
OUT_SINK_SOURCE = OUTPUT_DIR / "sink_source_edgelist.csv"
OUT_SINK_PIPELINE = OUTPUT_DIR / "sink_pipeline_edgelist.csv"
OUT_MERGED = OUTPUT_DIR / "merged_edge_list.csv"
