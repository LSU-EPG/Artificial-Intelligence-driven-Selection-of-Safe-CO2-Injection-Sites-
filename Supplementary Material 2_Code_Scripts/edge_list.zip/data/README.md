Put all your input files into `data/raw/`. Do not commit large datasets to Git.

If your filenames differ, edit `src/edge_list/config.py` (recommended) instead of hard-coding paths in scripts.
